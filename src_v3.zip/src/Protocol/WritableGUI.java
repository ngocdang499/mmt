package Protocol;

public interface WritableGUI {
    void write(String s);
}
