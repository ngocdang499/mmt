package Protocol;

public enum Status {
    ONLINE, AWAY, BUSY
}
