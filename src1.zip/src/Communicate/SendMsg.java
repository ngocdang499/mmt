package Communicate;
import Class.User;
import Protocol.AttachTagsMsg;

import java.io.File;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.ArrayList;

public class SendMsg {
    private static String SERVER;
    private static Integer TXTPORT = 50000;
    private static Integer FILEPORT = 60000;
    private static Integer SVRPORT = 44000;

    public static String getIP(String peerName, ArrayList<User> peerlst) {
        for(User u : peerlst) {
            if(peerName.matches(u.getUsrID())) {
                return u.getUsrIP();
            }
        }
        return null;
    }

    public static void broadcastStatus(User current,ArrayList<User> peerList, String server, int status) {
        // Send notice to Server
        SERVER = server;
        if (status == 0) {
            sendMessage(current, status, SERVER, SVRPORT);
        }
        // Send notice to peer
        for(User u : peerList) {
            if(u.getUsrStatus() == 1) {
                sendMessage(current,status,u.getUsrIP(),TXTPORT);
            }
        }
    }


    private static Socket socket;
    public static void sendMessage(User current, Object sendObj, String host, Integer port) {
        // Case 1: Send text message
        if(sendObj instanceof String)    {
            // Display message
            String msg = (String)sendObj;
            // Send mess to Other peer
            //========================================================================================
            try
            {
                int recvport = port;
                socket = new Socket(host,recvport); ;


                if(msg.contains("\n")) {
                    msg = msg.replaceAll("\n","\\ n");
                }

                String sendTxt = AttachTagsMsg.processTextMessage(current.getUsrID(),msg);
                //Send the message to peer
                ObjectOutputStream sender = new ObjectOutputStream(socket.getOutputStream());
                sender.writeObject(sendTxt);
                sender.flush();
                sender.close();
            }
            catch (Exception exception)
            {
                exception.printStackTrace();
            }
            finally
            {
                //Closing the socket
                try
                {
                    socket.close();
                    return;
                }
                catch(Exception ex)
                {
                    ex.printStackTrace();
                }
            }
        }

        // Case 2: Sending file
        if(sendObj instanceof File) {
            File sendFile = (File)sendObj;
            FileClient fc = new FileClient(host,port,sendFile.getAbsolutePath());
            // Gen notice ==============================================================================================
        }

        // Case 3: Sending notice about change in status
        if(sendObj instanceof Integer) {
            String msg = "";
            Integer status = (Integer)sendObj;
            try
            {
                int recvport = port;
                socket = new Socket(host,recvport); ;

                if(status==0)
                    msg = AttachTagsMsg.processOfflineStatus(current.getUsrID());
                else
                    msg = AttachTagsMsg.processOnlineStatus(current.getUsrID(),current.getUsrIP());

                //Send the message to peer
                ObjectOutputStream sender = new ObjectOutputStream(socket.getOutputStream());
                sender.writeObject(msg);
                sender.flush();
                sender.close();
            }
            catch (Exception exception)
            {
                exception.printStackTrace();
            }
            finally
            {
                //Closing the socket
                try
                {
                    socket.close();
                    return;
                }
                catch(Exception ex)
                {
                    ex.printStackTrace();
                }
            }
        }
    }
}
